<?php
$conn = mysqli_connect("localhost","root","","shout");
$path="http://localhost/shout";
session_start();
?>