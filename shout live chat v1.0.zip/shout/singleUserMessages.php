<?php
include "config.php";
if (!isset($_SESSION['username'])) {
    header("Location: {$path}");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="css/style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shout Messages</title>
</head>

<body>
    <nav>
        <div class="logo"><img src="images/logo.png" alt=""></div>
        <div class="right">
            <p>Logged in: <span><?php echo $_SESSION['username']; ?></span></p>
            <a href="logout.php?user=<?php echo $_SESSION['username']; ?>">Logout</a>
        </div>
    </nav>

    <section class="main">
        <div class="users">
            <h5>Online Users</h5>
            <div class="box">
                <ul>
                <li><a href="shout-messages.php"> All Messages</a></li>
                    <?php
                    $selectUsers = "SELECT * FROM users WHERE status = 1 ";
                    $result = mysqli_query($conn, $selectUsers) or die("Querry Unsuccessfull" . mysqli_error($conn));
                    while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                   
                        <li><a href="singleUserMessages.php?id=<?php echo $row['id']  ?>"><?php echo $row['username'];  ?></a></li>
                    <?php }
                    ?>
                </ul>
            </div>
        </div>
        <div class="messages">
            <div class="message-box">
                <?php
              $usernameId=$_GET['id'];
              $getUserMessages="SELECT message FROM shoutmessages WHERE user_id={$usernameId}";
            $mess= mysqli_query($conn,$getUserMessages);

                while ($row1 = mysqli_fetch_assoc($mess)) {
                    $selectName="SELECT username FROM users WHERE id={$usernameId}";
                    $result4=mysqli_query($conn,$selectName);
                   while($name = mysqli_fetch_assoc($result4)){
                ?>
                    <div class="message">
                        <p><span><?php echo $name['username']  ?>
                            </span> <?php echo $row1['message']  ?></p>
                    </div>
                <?php
                   }
                }
                ?>
            </div>
        </div>
        <div class="groups">
            <h5>Groups</h5>
            <ul>
                <li>Group 1</li>
                <li>Group 2</li>
                <li>Group 3</li>
            </ul>
        </div>
    </section>
</body>

</html>