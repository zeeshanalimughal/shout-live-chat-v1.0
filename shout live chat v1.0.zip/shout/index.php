<?php
include "config.php";
$username_err=$pass_err="";
if(isset($_POST['login'])){
$username=$password="";
if(empty($_POST['username']))
{
    $username_err="* Please enter username";
}else{
    $username=trim(mysqli_real_escape_string($conn,$_POST['username']));
}
if(empty($_POST['password']))
{
    $pass_err="* Please enter password";
}else{
    $password=md5(trim($_POST['password']));
}

if(!empty($username) && !empty($password)){
    $selectSql="SELECT * from users WHERE username='{$username}' AND password='{$password}'";
    $result=mysqli_query($conn,$selectSql) or die("Querry Unsuccessfull".mysqli_error($conn));
    if(mysqli_num_rows($result)>0){
        $updateStatus="UPDATE users SET status = 1 WHERE username='{$username}' AND password='{$password}'";
        if(mysqli_query($conn,$updateStatus)){
            $_SESSION['username']=$username;
            header("Location: {$path}/shout-messages.php");
        }
    }else{
        ?><script>alert("Account dose not exists");</script><?php
    }
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <div class="container">
            <form method="post">
              
                <h3>Login</h3>
                <hr>
           <div class="input">
            <p>Username</p>
            <input type="text" name="username" id="" placeholder="Enter username">
            <p style="color: red; font-size: 14px;"><?php echo $username_err  ?></p>
           </div>
           <div class="input">
            <p>Password</p>
            <input type="password" name="password" id="" placeholder="Enter Password">
            <p style="color: red; font-size: 14px;"><?php echo $pass_err  ?></p>
           </div>
                <button type="submit" name="login">Login</button>
                <a href="signup.php">Don't have an account...?</a>
            </form>
    </div>
</body>
</html>