<?php
include "config.php";
$username_err=$pass_err=$cpass_err="";
if(isset($_POST['register'])){
$username=$password=$cpassword="";
if(empty($_POST['username']))
{
    $username_err="* Username is required";
}else{
    $username=trim(mysqli_real_escape_string($conn,$_POST['username']));
}
if(empty($_POST['password']))
{
    $pass_err="* Password is required";
}else{
    $password=md5(trim($_POST['password']));
}
if(empty($_POST['cpassword']))
{
    $cpass_err="* Please confirm the password";
}else{
    $cpassword=md5(trim($_POST['cpassword']));
}
if(!empty($username) && !empty($password) && !empty($cpassword)){
    if($password==$cpassword){

    
    $sqlInsert="INSERT INTO `users`(`username`, `password`, `status`) VALUES('{$username}','{$password}',0)";
    if(mysqli_query($conn,$sqlInsert)){
        header("Location: {$path}");
    }
}else{
    $cpass_err="* Password didn't match";
}
}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/style.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign-Up</title>
</head>
<body>
    <div class="container">
            <form method="post">
              
                <h3>Sign-Up</h3>
                <hr>
           <div class="input">
            <p>Username</p>
            <input type="text" name="username" id="" placeholder="Enter username">
            <p style="color: red; font-size: 14px;"><?php echo $username_err  ?></p>
           </div>
           <div class="input">
            <p>Password</p>
            <input type="password" name="password" id="" placeholder="Enter Password">
            <p style="color: red; font-size: 14px;"><?php echo $pass_err  ?></p>

           </div>
           <div class="input">
            <p>Confirm Password</p>
            <input type="password" name="cpassword" id="" placeholder="Enter Password">
            <p style="color: red; font-size: 14px;"><?php echo $cpass_err  ?></p>

           </div>
                <button type="submit" name="register">Register</button>
                <a href="index.php">Already have an account...?</a>
            </form>
    </div>
</body>
</html>