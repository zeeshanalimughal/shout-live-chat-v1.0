<?php
include "config.php";
$usernameGet=$_GET['user'];
$updatedStatus="UPDATE users SET status=0 WHERE username = '{$usernameGet}'";
if(mysqli_query($conn,$updatedStatus)){
    session_destroy();
    unset($_SESSION['username']);
    header("Location: {$path}");
}
?>